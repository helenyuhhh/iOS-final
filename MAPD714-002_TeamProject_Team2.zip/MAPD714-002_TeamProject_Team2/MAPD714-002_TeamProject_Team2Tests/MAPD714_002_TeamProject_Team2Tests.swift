//
//  MAPD714_002_TeamProject_Team2Tests.swift
//  MAPD714-002_TeamProject_Team2Tests
//
//  Created by Windy on 2024-10-29.
//

import Testing
@testable import MAPD714_002_TeamProject_Team2

struct MAPD714_002_TeamProject_Team2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

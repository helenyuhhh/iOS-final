//
//  ConfirmationPageView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-11.
//

import SwiftUI

struct PhoneDetailView: View {
    @EnvironmentObject var phoneInfo: PhoneInfo
    @EnvironmentObject var customerInfo: CustomerInfo
    @State var selectedProvince: Provinces = .on
    @StateObject var orderModel = OrderDetailViewModel(context: PersistenceController.shared.container.viewContext)


    
    var body: some View {
        
            VStack{
                if (orderModel.orders.isEmpty){
                    Text("No order found").fontWeight(.bold).font(.title2)
                    
                }
                else {
                    let order = orderModel.orders.last
                    Text("Order Deatils:").fontWeight(.bold).font(.largeTitle).frame(alignment:.leading)
                    if(phoneInfo.phoneType == "IPhone") {
                        Image("iphone").resizable().aspectRatio(contentMode: .fit).foregroundStyle(.tint).frame(width:100,height:100)
                        Text("Phone Model:  \(phoneInfo.phoneModel)").font(.title)
                    }
                    else if(phoneInfo.phoneType == "Samsung") {
                        Image("samsung").resizable().aspectRatio(contentMode: .fit).foregroundStyle(.tint).frame(width:100,height:100)
                        Text("Phone Model:  \(phoneInfo.phoneModel)").font(.title)
                    }
                    else {
                        Image("pixel").resizable().aspectRatio(contentMode: .fit).foregroundStyle(.tint).frame(width:100,height:100)
                        Text("Phone Model:  \(phoneInfo.phoneModel)").font(.title)
                    }
                List{
                   // Text ("Order Number: \(order?.order_number ?? "N/A")").fontWeight(.bold).font(.headline)
                    Text("Phone Color:  \(order?.color ?? "N/A")").fontWeight(.bold).font(.headline)
                    Text("Phone Storage:  \(order?.storage ?? "N/A")").fontWeight(.bold).font(.headline)
                    Text("Phone Price:  $\(order?.price ?? 0)")
                        .fontWeight(.bold)
                        .font(.headline)
                    
                }
                NavigationLink(destination: PaymentPageView()) {
                    Text("Go To Check Out").fontWeight(.bold)
                }.frame(width: 200, height: 50).background(Color(red: 0.28, green: 0.85, blue: 0.98, opacity: 0.35)).cornerRadius(25).foregroundColor(.black).offset(y: -220).padding(.top, 50)
                    
                }
            }
            
        }
        
    }
    

struct PhoneDetailView_Previews: PreviewProvider {
    // declare the variable to pass the
    // value?
    static var previews: some View {
        PhoneDetailView()
            .environmentObject(PhoneInfo())

        
    }
}



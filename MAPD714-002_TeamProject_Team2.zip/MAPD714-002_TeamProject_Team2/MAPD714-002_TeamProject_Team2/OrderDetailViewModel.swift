
//
//  PhoneDBViewModel.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-19.
// class for core db view model class, add fetch function here?

import Foundation
import CoreData

class OrderDetailViewModel: ObservableObject {
    // array of saved customer info object
    @Published var orders: [PhoneOrder] = []
    private let viewContext: NSManagedObjectContext
    

   
    init(context: NSManagedObjectContext) {
        viewContext = context
        // user define method to fetch data from Product
        fetchOrderInfo()
    }
    // fetch the customer
    func fetchOrderInfo(){
        let request = NSFetchRequest<PhoneOrder>(entityName: "PhoneOrder")
        do {
            // the fetch result will be saved into saved customer
            orders = try viewContext.fetch(request)
        } catch {
            print("Error in fetching customer: \(error)")
        }
    }
    
    // add a customer
    func addOrder(newPhoneInfo: PhoneInfo){
        
        let newOrder = PhoneOrder(context: viewContext)
        newOrder.phone_model = newPhoneInfo.phoneModel
        newOrder.color = newPhoneInfo.phoneColor
        newOrder.storage = newPhoneInfo.phoneStorage
        newOrder.price = Int32(newPhoneInfo.phonePrice)
        newOrder.order_number = "\(Int.random(in: 100000000..<999999999))"
        saveContext()
        
    }
    // edit the info
    private func saveContext() {
        do {
            // .save() is the way to add
            try viewContext.save()
            fetchOrderInfo()
        } catch {
            print("Error in saving context: \(error)")
        }
    }
    
}

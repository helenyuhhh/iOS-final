//
//  ConfirmationPageView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-11.
//

import SwiftUI
enum SamsungModel: String, CaseIterable, Identifiable {
        case galS23 = "Samsung Galaxy S23", galS24 = "Samsung Galaxy S24", galFo5  = "Samsung Galaxy Fold 5", galFl5 =  "Samsung Galaxy Flip 5"
        var id: Self { self }
    }
// declare phone color
enum SamsungColor: String, CaseIterable, Identifiable {
        case black = "Phantom Black", sliver = "Phantom Sliver", burgundy = "Burgundy", lavender = "Lavender"
        var id: Self { self }
    }
enum SamsungStorage: String, CaseIterable, Identifiable {
        case gb128 = "128GB", gb256 = "256GB", gb512 = "512GB"
        var id: Self { self }
    }

struct SamsungPageView: View {
    @EnvironmentObject var phoneInfo: PhoneInfo
    @StateObject var orderModel = OrderDetailViewModel(context: PersistenceController.shared.container.viewContext)

    @State var selectedModel: SamsungModel = .galS23
    @State var selectedColor: SamsungColor = .black
    @State var selectedStorage: SamsungStorage = .gb128
    // declare variable to store the model, price and storage
    @State var phonePrice: Int = 0 // int
    @State var showDetails = false
    var body: some View {
        VStack{
            Image("samsung").resizable().aspectRatio(contentMode: .fit).foregroundStyle(.tint).frame(width:100,height:100)
            Text("Samsung Galaxy Series").font(.title)
            // declare a picker
            List {
                Picker("Model", selection: $selectedModel){
                    Text("Samsung Galaxy S23").tag(SamsungModel.galS23)
                    Text("Samsung Galaxy S24").tag(SamsungModel.galS24)
                    Text("Samsung Galaxy Fold 5").tag(SamsungModel.galFo5)
                    Text("Samsung Galaxy Flip 5").tag(SamsungModel.galFl5)
                }
                HStack{
                    Picker("Color", selection: $selectedColor){
                        Text("Phantom Black").tag(SamsungColor.black)
                        Text("Phantom Sliver").tag(SamsungColor.sliver)
                        Text("Burgundy").tag(SamsungColor.burgundy)
                        Text("Lavender").tag(SamsungColor.lavender)
                    }
                }
                HStack{
                    Picker("Storage", selection: $selectedStorage){
                        Text("128GB").tag(SamsungStorage.gb128)
                        Text("256GB").tag(SamsungStorage.gb256)
                        Text("512GB").tag(SamsungStorage.gb512)
                    }
                }
                Button("Check Pirce"){
                    phonePriceCalculation()
                    assignValue()
                    showDetails.toggle()
                }.fontWeight(.bold).frame(width: 200, height: 50).background(Color(red: 0.28, green: 0.85, blue: 0.98, opacity: 0.35)).cornerRadius(25).foregroundColor(.black).padding(.top, 30).padding(.leading, 70)
                Group{
                    if showDetails {
                        Text("\(selectedModel.rawValue) \(selectedColor.rawValue) \(selectedStorage.rawValue) for $\(phonePrice)").padding()
                    }
                    
                }
            }
            NavigationLink(destination: PhoneDetailView()) {
                
                Text("Check Order Details").fontWeight(.bold)
            }.frame(width: 200, height: 50).background(Color(red: 0.28, green: 0.85, blue: 0.98, opacity: 0.35)).cornerRadius(25).foregroundColor(.black).offset(y:-160).simultaneousGesture(TapGesture().onEnded {
                storeData()
            }) // end of button
        }
}
private func phonePriceCalculation(){
    // for .galS23
    if (selectedModel == .galS23 && selectedStorage == .gb128) {
        phonePrice = 900
    }
    else if (selectedModel == .galS23 && selectedStorage == .gb256) {
        phonePrice = 1000
    }
    else if(selectedModel == .galS23 && selectedStorage == .gb512){
        phonePrice = 1100
    }
    // galS24
    if (selectedModel == .galS24 && selectedStorage == .gb128) {
        phonePrice = 1000
    }
    else if (selectedModel == .galS24 && selectedStorage == .gb256) {
        phonePrice = 1150
    }
    else if(selectedModel == .galS24 && selectedStorage == .gb512){
        phonePrice = 1300
    }
    // galFo5
    if (selectedModel == .galFo5 && selectedStorage == .gb128) {
        phonePrice = 1050
    }
    else if (selectedModel == .galFo5 && selectedStorage == .gb256) {
        phonePrice = 1200
    }
    else if(selectedModel == .galFo5 && selectedStorage == .gb512){
        phonePrice = 1350
    }
    // for galFl5
    if (selectedModel == .galFl5 && selectedStorage == .gb128) {
        phonePrice = 1100
    }
    else if (selectedModel == .galFl5 && selectedStorage == .gb256) {
        phonePrice = 1200
    }
    else if(selectedModel == .galFl5 && selectedStorage == .gb512){
        phonePrice = 1300
    }
    
  }
    private func assignValue(){
        phoneInfo.phoneModel = selectedModel.rawValue
        phoneInfo.phoneColor = selectedColor.rawValue
        phoneInfo.phoneStorage = selectedStorage.rawValue
        phoneInfo.phonePrice = phonePrice
        phoneInfo.phoneType = "Samsung"
        
        
    }
    private func storeData(){
        let newOrderInfo = PhoneInfo()
        newOrderInfo.phoneModel = selectedModel.rawValue
        newOrderInfo.phoneColor = selectedColor.rawValue
        newOrderInfo.phoneStorage = selectedStorage.rawValue
        newOrderInfo.phonePrice = phonePrice
        orderModel.addOrder(newPhoneInfo: newOrderInfo)
    }

}

#Preview {
SamsungPageView()
}


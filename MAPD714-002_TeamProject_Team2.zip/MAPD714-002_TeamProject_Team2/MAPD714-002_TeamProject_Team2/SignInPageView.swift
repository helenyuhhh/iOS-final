//
//  ConfirmationPageView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-11.
//
/*
 my idea right now:
 after getting the input, search every customer stored in the
  customer db, if both matches, get the index of the customer array and fetch that customer?*/
import SwiftUI

struct SignInPageView: View {
    // the customer Model doesn't affect the preview...
    @StateObject var custmerModel = PhoneDBViewModel(context: PersistenceController.shared.container.viewContext)
    @State var username: String = ""
    @State var password: String = ""
    @State var signInOK: Bool = false
    @State var showAlert: Bool = false
    var body: some View {
        VStack(alignment: .leading, spacing: 10){
            Text("Please Enter Your User Name:").fontWeight(.bold).font(.title2).offset(y:-100)
            TextField("", text: $username).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3).offset(y:-90)
        }
        .padding()
        
        VStack(alignment: .leading, spacing: 10){
            Text("Please Enter Your password:").fontWeight(.bold).font(.title2).offset(y:-80)
            SecureField("", text: $password).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3).offset(y:-70)
        }.padding()
        Button(action: {checkCustomer()}) {
                        Text("Start shopping")
                .font(.title3).fontWeight(.bold)
                            .padding()
                            .background(.gray)
                            .foregroundColor(.black)
                            .cornerRadius(25)
                    }
        
        .padding()
        // .onAppear{checkCustomer()}
        NavigationLink(destination: PhonePageView(username:username),isActive: $signInOK) {
        }.offset(y:-50).background(.cyan)
                .alert(isPresented: $showAlert) {
                        Alert(title: Text("Sign In Error"), message: Text("Please input correct username and password"), dismissButton: .default(Text("OK")))}
        
    }
    
    // navigation link should ferform this function to check whether the customer is from the db
    private func checkCustomer(){
        // get the input user name and password, search in the customerModerl.customers
        // search the inout username and compare the password
        // customers is an array with Customer
        custmerModel.customers.forEach { customer in
            if (customer.username == username && customer.password == password){
                showAlert = false
                signInOK = true
            }
            else {
                signInOK = false
                showAlert = true
            }
            
        }
        
    }
}



#Preview {
    SignInPageView()
}

//
//  CustomerInfoEditView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-19.
// this page is to edit and save

import SwiftUI
import PhotosUI

struct CustomerInfoEditView: View {
    @ObservedObject var customerModel: PhoneDBViewModel
    @Binding var editableCustomer: Customer?
    @Environment(\.presentationMode) var presentationMode
    // variables to store the original data: address, pr, on, zip code is one part
    // password is another part
    @State var addressNew: String = ""
    @State var cityNew: String = ""
    @State var provinceNew: Provinces = .on
    @State var countryNew: String = ""
    @State var zipCodeNew: String = ""
    @State var phoneNew: String = ""
    // old stuff
    @State var oldAddress: String = ""
    @State var oldCity: String = ""
    @State var oldProvince: String = ""
    @State var oldZipCode: String = ""
    @State var oldPhone: String = ""
    // for photo picker
    @State private var oldImageData: Data? = nil
    @State private var imageData: Data? = nil
    @State private var selectedPhoto: PhotosPickerItem? = nil
    
    var body: some View {
        PhotosPicker(selection: $selectedPhoto,
                     matching:.images,
                     photoLibrary: .shared()){
            //Text("Select Profile").foregroundColor(.white).cornerRadius(8)
            if let imageData, let uiImage = UIImage(data: imageData){
                Image(uiImage:uiImage)
                    .resizable().frame(width:100, height:100).clipShape(Circle()).overlay(Circle().stroke(Color.white, lineWidth:3)).shadow(radius: 3).scaledToFit()
            }else{
                Circle().fill(Color.gray.opacity(0.5)).frame(width:100, height:100).overlay((Text("Uplpad")).foregroundColor(.black))
            }
        }.onChange(of: selectedPhoto){ newItem in
            Task{
                if let data = try? await newItem?.loadTransferable(type: Data.self){
                    imageData = data
                }
            }
            
        }
        
        List{
            HStack(){
                Text("New address:").fontWeight(.bold).font(.headline)
                TextField("", text:$addressNew).frame(height:35).foregroundColor(.primary).background(.cyan).opacity(0.3)
            }
            // city
            HStack(){
                Text("City:").fontWeight(.bold).font(.headline)
                TextField("", text:$cityNew ?? $oldCity).frame(height:35).foregroundColor(.primary).background(Color.mint).opacity(0.3)
            }
            // province
            HStack(){
                Text("Province:").fontWeight(.bold).font(.headline)
                Picker("", selection: $provinceNew){
                    Text("Ontario").tag(Provinces.on)
                    Text("Quebec").tag(Provinces.qc)
                    Text("British Columbia").tag(Provinces.bc)
                    Text("Alberta").tag(Provinces.ab)
                }
                
            }
            // zip code
            HStack(){
                Text("Zip Code:").fontWeight(.bold).font(.title3)
                TextField("", text:$zipCodeNew).frame(height:35).foregroundColor(.primary).background(.cyan).opacity(0.3)
            }
            // phone number
            HStack(){
                Text("Phone Number:").fontWeight(.bold).font(.title3)
                TextField("", text:$phoneNew).frame(height:35).foregroundColor(.primary).background(.cyan).opacity(0.3)
            }
        }
        
            NavigationLink(destination: CustomerInfoViewTwo(custmerModel:customerModel)) {
                    Text("Save").fontWeight(.bold)
                }.frame(width: 200, height: 45).background(Color(red: 0.28, green: 0.85, blue: 0.98, opacity: 0.35)).cornerRadius(25).offset(y:-100).foregroundColor(.black).simultaneousGesture(TapGesture().onEnded {
                    storeData()
                    presentationMode.wrappedValue.dismiss()
                }) // end of button
                 
                .onAppear(){
                    editableCustomer = customerModel.customers.last
                    if let customer = editableCustomer{
                        oldAddress = customer.address ?? "N/A"
                        oldCity = customer.city ?? "N/A"
                        oldProvince = customer.province ?? "N/A"
                        oldZipCode = customer.zipcode ?? "N/A"
                        oldPhone = customer.phone_num ?? "N/A"
                        //oldImageData = customer.profile as? Data ?? Data()
                    }
                    if (addressNew == "") {
                        addressNew = oldAddress
                    }
                    if (zipCodeNew == "") {
                        zipCodeNew = oldZipCode
                    }
                    if (phoneNew == "") {
                        phoneNew = oldPhone
                    }
                    if (cityNew == "") {
                        cityNew = oldCity
                    }
                    if (imageData == nil){
                        imageData = oldImageData
                    }
                    
                }
        }
        
    // }
    private func storeData(){
        guard let editableCustomer = editableCustomer else {
                print("No customer selected for editing.")
                return
            }
        let newCustomerInfo = CustomerInfo()
        newCustomerInfo.street = addressNew
        newCustomerInfo.city = cityNew
        newCustomerInfo.province = provinceNew.rawValue // Make sure to store the correct province value
        newCustomerInfo.zipCode = zipCodeNew
        newCustomerInfo.phoneNumber = phoneNew
        newCustomerInfo.profileImageData = imageData
        customerModel.editCustomer(editableCustomer, with: newCustomerInfo)
        clearText()}
    private func clearText(){
        addressNew = ""
        cityNew = ""
        provinceNew = .on
        countryNew = ""
        zipCodeNew = ""
        phoneNew = ""
    }
}



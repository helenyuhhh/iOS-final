//
//  ConfirmationPageView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-11.
//
import SwiftUI

struct ContentView: View {
    @StateObject var phoneDBViewModel = PhoneDBViewModel(context: PersistenceController.shared.container.viewContext)
    
        var body: some View {
           
                
              ZStack {
                
                // put the image logo
                Color(red: 0.11, green: 0.13, blue: 0.16).ignoresSafeArea()
                
                VStack{
                    Image("logo").resizable().aspectRatio(contentMode: .fit).foregroundStyle(.tint).frame(width:300,height:300 ).offset(y:-150)
                    Text("Centennial College Phone Shopping Plateform").multilineTextAlignment(.center).foregroundColor(.gray).offset(y: -180).font(.title).fontWeight(.semibold)
                    // defining the button to go to the next page
                    NavigationLink(destination: PhoneDBView(custmerModel: phoneDBViewModel)) {
                        Text("Register").fontWeight(.bold)
                    }.frame(width: 200, height: 50).background(.gray).cornerRadius(25).foregroundColor(.black).offset(y:-150)
                    NavigationLink(destination: SignInPageView()) {
                        Text("Sign In").fontWeight(.bold)
                    }.frame(width: 200, height: 50).background(.gray).cornerRadius(25).foregroundColor(.black).offset(y:-130)
                }
            }
              //.navigationTitle("Main Page")
        }
    
}

/*struct  RegisterPageView: View{
    var body: some View{
        VStack{
            Text("Hello, Register Page")
        }
        //.navigationTitle("Register Page")
    }
    
}
struct  SignInPageView: View{
    var body: some View{
        VStack{
            Text("Hello, login Page")
        }
        //.navigationTitle("SignIn Page")
    }
    
}*/
/*#Preview {
    ContentView()
}*/

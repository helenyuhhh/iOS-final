//
//  ConfirmationPageView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-11.
//

import SwiftUI
import Combine

class CustomerInfo: ObservableObject {
    @Published var userName: String = ""
    @Published var email: String = ""
    @Published var street: String = "" // address in db
    @Published var province: String = ""
    @Published var zipCode: String = ""
    @Published var phoneNumber: String = "" // phone num in db
    @Published var password: String = "" // psw in db
    @Published var country: String = "" // country in db
    @Published var full_name: String = "" // full name in db
    @Published var city: String = "" // city in db
    @Published var profileImageData: Data? 
    
    var profileImage: Image {
            if let data = profileImageData, let uiImage = UIImage(data: data) {
                return Image(uiImage: uiImage)
            } else {
                return Image("profile")
            }
        }
}


//
//  ConfirmationPageView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-11.
//
import SwiftUI
// declare IPhone Models
enum PhoneModel: String, CaseIterable, Identifiable {
        case iPhone14 = "IPhone 14", iPhone15 = "IPhone 15", iPhone16  = "IPhone 16", iPhone16Pro =  "IPhone 16 Pro"
        var id: Self { self }
    }
// declare phone color
enum PhoneColor: String, CaseIterable, Identifiable {
        case gold = "Gold", sliver = "Sliver", spaceGray = "Space Gray", black = "Black"
        var id: Self { self }
    }
enum PhoneStorage: String, CaseIterable, Identifiable {
        case gb128 = "128GB", gb256 = "256GB", gb512 = "512GB"
        var id: Self { self }
    }
// declare an exrtension variable for model, price and color

struct IPhonePageView: View {
    // environment object
    @EnvironmentObject var phoneInfo: PhoneInfo
    @StateObject var orderModel = OrderDetailViewModel(context: PersistenceController.shared.container.viewContext)
    // declare default picker value?
    @State var selectedModel: PhoneModel = .iPhone14
    @State var selectedColor: PhoneColor = .gold
    @State var selectedStorage: PhoneStorage = .gb128
    // declare variable to store the model, price and storage
    @State var phonePrice: Int = 0 // int
    @State var showDetails = false
    // create variable to store the string data
    // I want to create @Environment variables to passdown values
    // @State var phoneModel: String = ""
    // @State var phoneColor: String = ""
    // @State var phoneStorage: String = ""
        var body: some View {
            VStack{
                Image("iphone").resizable().aspectRatio(contentMode: .fit).foregroundStyle(.tint).frame(width:100,height:100)
                Text("IPhone").font(.title)
                // declare a picker
                List {
                    Picker("IPhoneModel", selection: $selectedModel){
                        Text("IPhone 14").tag(PhoneModel.iPhone14)
                        Text("IPhone 15").tag(PhoneModel.iPhone15)
                        Text("IPhone 16").tag(PhoneModel.iPhone16)
                        Text("IPhone 16 Pro").tag(PhoneModel.iPhone16Pro)
                        // phoneModel = "\(selectedModel)"
                    }
                    HStack{
                        Picker("IPhoneColor", selection: $selectedColor){
                            Text("Gold").tag(PhoneColor.gold)
                            Text("Sliver").tag(PhoneColor.sliver)
                            Text("Space Gray").tag(PhoneColor.spaceGray)
                            Text("Black").tag(PhoneColor.black)
                        }
                    }
                    HStack{
                        Picker("IPhoneStorage", selection: $selectedStorage){
                            Text("128GB").tag(PhoneStorage.gb128)
                            Text("256GB").tag(PhoneStorage.gb256)
                            Text("512GB").tag(PhoneStorage.gb512)
                        }
                    }
                    Button("Check Pirce"){
                        phonePriceCalculation()
                        assignValue()
                        showDetails.toggle()
                    }.fontWeight(.bold).frame(width: 200, height: 50).background(Color(red: 0.28, green: 0.85, blue: 0.98, opacity: 0.35)).cornerRadius(25).foregroundColor(.black).padding(.top, 30).padding(.leading, 70)
                    Group{
                        if showDetails {
                            Text("\(selectedModel.rawValue) \(selectedColor.rawValue) \(selectedStorage.rawValue) for $\(phonePrice)").padding(.leading, 50)
                        }
                        
                    }
                }
                NavigationLink(destination: PhoneDetailView()) {
                    Text("Check Order Details").fontWeight(.bold)
                }.frame(width: 200, height: 50).background(Color(red: 0.28, green: 0.85, blue: 0.98, opacity: 0.35)).cornerRadius(25).foregroundColor(.black).offset(y:-190).simultaneousGesture(TapGesture().onEnded {
                    storeData()
                }) // end of button
            }
    }
    private func phonePriceCalculation(){
        // for 14
        if (selectedModel == .iPhone14 && selectedStorage == .gb128) {
            phonePrice = 900
        }
        else if (selectedModel == .iPhone14 && selectedStorage == .gb256) {
            phonePrice = 1000
        }
        else if(selectedModel == .iPhone14 && selectedStorage == .gb512){
            phonePrice = 1100
        }
        // for 15
        if (selectedModel == .iPhone15 && selectedStorage == .gb128) {
            phonePrice = 1000
        }
        else if (selectedModel == .iPhone15 && selectedStorage == .gb256) {
            phonePrice = 1150
        }
        else if(selectedModel == .iPhone15 && selectedStorage == .gb512){
            phonePrice = 1300
        }
        // for 16
        if (selectedModel == .iPhone16 && selectedStorage == .gb128) {
            phonePrice = 1050
        }
        else if (selectedModel == .iPhone16 && selectedStorage == .gb256) {
            phonePrice = 1200
        }
        else if(selectedModel == .iPhone16 && selectedStorage == .gb512){
            phonePrice = 1350
        }
        // for 16 pro
        if (selectedModel == .iPhone16Pro && selectedStorage == .gb128) {
            phonePrice = 1100
        }
        else if (selectedModel == .iPhone16Pro && selectedStorage == .gb256) {
            phonePrice = 1200
        }
        else if(selectedModel == .iPhone16Pro && selectedStorage == .gb512){
            phonePrice = 1300
        }
        
    }
    private func assignValue(){
        phoneInfo.phoneModel = selectedModel.rawValue
        phoneInfo.phoneColor = selectedColor.rawValue
        phoneInfo.phoneStorage = selectedStorage.rawValue
        phoneInfo.phonePrice = phonePrice
        phoneInfo.phoneType = "IPhone"
    }
    /**
     newOrder.phone_model = newPhoneInfo.phoneModel
     newOrder.color = newPhoneInfo.phoneColor
     newOrder.storage = newPhoneInfo.phoneStorage
     newOrder.price = Int32(newPhoneInfo.phonePrice)
     */
    private func storeData(){
        let newOrderInfo = PhoneInfo()
        newOrderInfo.phoneModel = selectedModel.rawValue
        newOrderInfo.phoneColor = selectedColor.rawValue
        newOrderInfo.phoneStorage = selectedStorage.rawValue
        newOrderInfo.phonePrice = phonePrice
        orderModel.addOrder(newPhoneInfo: newOrderInfo)
    }

    
}


//
//  ConfirmationPageView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-11.
//
/* confirmation view will show name address..., phone detais(all we have in the PhoneDetail wiew + the order number, and the
 customer*/

import SwiftUI

struct ConfirmationPageView: View {
    @EnvironmentObject var phoneInfo: PhoneInfo
    @EnvironmentObject var customerInfo: CustomerInfo
    @StateObject var orderModel = OrderDetailViewModel(context: PersistenceController.shared.container.viewContext)
    @StateObject var customerModel = PhoneDBViewModel(context: PersistenceController.shared.container.viewContext)
    @State var passedAddress: String
    
    var body: some View {
        let order = orderModel.orders.last
        let customer = customerModel.customers.last
        
            VStack{
                Text("Order Success!").fontWeight(.bold).font(.largeTitle).frame(alignment:.leading)
                if(phoneInfo.phoneType == "IPhone") {
                    Image("iphone").resizable().aspectRatio(contentMode: .fit).foregroundStyle(.tint).frame(width:100,height:100)
                    Text("Phone Model:  \(phoneInfo.phoneModel)").font(.title)
                }
                else if(phoneInfo.phoneType == "Samsung") {
                    Image("samsung").resizable().aspectRatio(contentMode: .fit).foregroundStyle(.tint).frame(width:100,height:100)
                    Text("Phone Model:  \(phoneInfo.phoneModel)").font(.title)
                }
                else {
                    Image("pixel").resizable().aspectRatio(contentMode: .fit).foregroundStyle(.tint).frame(width:100,height:100)
                    Text("Phone Model:  \(phoneInfo.phoneModel)").font(.title)
                }
                
                List{
                    if let order = order {
                        /*Text("Order NUmber:  \(order?.order_number)").font(.title3)*/
                        Text("Order Number:  \(order.order_number ?? "N/A")").fontWeight(.bold).font(.title3)
                        Text("Phone Color:  \(order.color ?? "N/A")").fontWeight(.bold).font(.title3)
                        Text("Phone Storage:  \(order.storage ?? "N/A")").fontWeight(.bold).font(.title3)
                        Text("Phone Price:  $\(order.price ?? 0)")
                            .fontWeight(.bold)
                            .font(.title3)
                    }
                }
                List{
                    if let customer = customer {
                        Text("Your name:  \(customer.full_name ?? "N/A")").fontWeight(.bold).font(.headline)
                        Text("Email:  \(customer.email ?? "N/A")").fontWeight(.bold).font(.headline)
                        Text("Phone Number: \(customer.phone_num ?? "N/A")").fontWeight(.bold).font(.headline)
                        Text("Street: \(customer.address ?? "N/A")").fontWeight(.bold).font(.headline)
                        Text("Province: \(customer.province ?? "N/A")").fontWeight(.bold).font(.headline)
                        if (passedAddress == "old address") {
                            Text("Your order will be delivered to your home").fontWeight(.bold).font(.headline)
                        }
                        else {
                            Text("Your order will be available at: \n \(passedAddress)").fontWeight(.bold).font(.headline)
                        }
                    }
                    //
                    
                    //Text("Your order will be available at: "\passedAddress)
                }
            }
        }
    }


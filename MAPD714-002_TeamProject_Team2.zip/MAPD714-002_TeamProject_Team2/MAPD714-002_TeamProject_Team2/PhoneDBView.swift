//
//  PhoneDBView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-19.

// class for core db view, maybe after the registration /login page? for registration?

import SwiftUI
import PhotosUI

struct PhoneDBView: View {
    @StateObject var custmerModel = PhoneDBViewModel(context: PersistenceController.shared.container.viewContext)
    // @State private var showingEditView = false
    // @State private var editableCustomer: Customer?
    //@State private var editableCustomer: Customer?
    //@State private var customerInfo: Customer
    // declaire those parameters first, 10 total
    @State private var username: String = ""
    @State private var fullName: String = ""
    @State private var address: String = "" // street is the address
    @State private var email: String = ""
    @State private var phoneNum: String = ""
    @State private var password: String = ""
    @State private var city: String = ""
    //@State private var province: String = ""
    @State private var zipcode: String = ""
    @State private var country: String = ""
    // for picker
    @State var selectedProvince: Provinces = .on
    // validation
    @State private var validphone: Bool = false
    @State private var validemail: Bool = false
    @State private var validname: Bool = false
    @State private var validZip: Bool = false
    @State private var gotoNext: Bool = false
    @State private var showAlert: Bool = false
    // for uplaod profile
    @State private var imageData: Data? = nil
    @State private var selectedPhoto: PhotosPickerItem? = nil
    var body: some View {
        // Text("Hello, customer info from core db!")
       // NavigationView{
                // user name
        // i want to add user profile pic
        // if let is swiftUI way of if(imageData), just make sure the imageData is not nil
        // set up photopicker
        PhotosPicker(selection: $selectedPhoto,
                     matching:.images,
                     photoLibrary: .shared()){
            //Text("Select Profile").foregroundColor(.white).cornerRadius(8)
            if let imageData, let uiImage = UIImage(data: imageData){
                Image(uiImage:uiImage)
                    .resizable().frame(width:100, height:100).clipShape(Circle()).overlay(Circle().stroke(Color.white, lineWidth:3)).shadow(radius: 3).scaledToFit()
            }else{
                Circle().fill(Color.gray.opacity(0.5)).frame(width:100, height:100).overlay((Text("Uplpad")).foregroundColor(.black))
            }
        }.onChange(of: selectedPhoto){ newItem in
            Task{
                if let data = try? await newItem?.loadTransferable(type: Data.self){
                    imageData = data
                }
            }
            
        }
                List{
                    
                    // user full name
                    HStack(){
                        Text("Name:").fontWeight(.bold).font(.headline)
                        TextField("", text:$fullName).frame(height:35).foregroundColor(.primary).background(Color.mint).opacity(0.3)
                    }
                    //user username
                    HStack(){
                        Text("User Name:").fontWeight(.bold).font(.headline)
                        TextField("", text:$username).frame(height:35).foregroundColor(.primary).background(Color.mint).opacity(0.3)
                    }
                    // password
                    HStack(){
                        Text("Password:").fontWeight(.bold).font(.headline)
                        TextField("", text:$password).frame(height:35).foregroundColor(.primary).background(Color.mint).opacity(0.3)
                    }
                    // user email
                    HStack(){
                        Text("Email:").fontWeight(.bold).font(.headline)
                        TextField("", text:$email).frame(height:35).foregroundColor(.primary).background(.cyan).opacity(0.3)
                    }
                    // user street
                    HStack(){
                        Text("Street:").fontWeight(.bold).font(.headline)
                        TextField("", text:$address).frame(height:35).foregroundColor(.primary).background(.cyan).opacity(0.3)
                    }
                    // city
                    HStack(){
                        Text("City:").fontWeight(.bold).font(.headline)
                        TextField("", text:$city).frame(height:35).foregroundColor(.primary).background(Color.mint).opacity(0.3)
                    }
                    // province
                    HStack(){
                        Text("Province:").fontWeight(.bold).font(.headline)
                        Picker("", selection: $selectedProvince){
                            Text("Ontario").tag(Provinces.on)
                            Text("Quebec").tag(Provinces.qc)
                            Text("British Columbia").tag(Provinces.bc)
                            Text("Alberta").tag(Provinces.ab)
                        }
                        
                    }
                    // country
                    HStack(){
                        Text("Country:").fontWeight(.bold).font(.headline)
                        TextField("", text:$country).frame(height:35).foregroundColor(.primary).background(Color.mint).opacity(0.3)
                    }
                    // zip code
                    HStack(){
                        Text("Zip Code:").fontWeight(.bold).font(.title3)
                        TextField("", text:$zipcode).frame(height:35).foregroundColor(.primary).background(.cyan).opacity(0.3)
                    }
                    // phone number
                    HStack(){
                        Text("Phone Number:").fontWeight(.bold).font(.title3)
                        TextField("", text:$phoneNum).frame(height:35).foregroundColor(.primary).background(.cyan).opacity(0.3)
                    }
                    // declare a button and store the data into db, after the
                    // customer inputing their onformation, we should go to customer information page,
                    // in that page, customer can edit their phone number, address, city, province and country?
                    
                    
                }
        
                Button(action: {canGoNext()}) {
                        Text("Start shopping")
                  .font(.title3).fontWeight(.bold).frame(width: 200, height: 50)
                  .background(Color(red: 0.24, green: 0.75, blue: 0.99, opacity: 0.39))
                            .foregroundColor(.black).cornerRadius(25)
                }
                .padding()
                NavigationLink(destination: CustomerInfoViewTwo(custmerModel:custmerModel), isActive: $gotoNext) {}.alert(isPresented: $showAlert){
                    if (!validphone) {
                        Alert(title: Text("Invalid Phone Number"), message: Text("Please enter a valid phone number"), dismissButton: .default(Text("OK")))
                    }
                    else if(!validname) {
                        Alert(title: Text("Invalid Name"), message: Text("Please enter a valid name"), dismissButton: .default(Text("OK")))
                    }
                    else if (!validemail){
                        Alert(title: Text("Invalid Email"), message: Text("Please enter a valid email"), dismissButton: .default(Text("OK")))
                    }
                    else if (!validZip){
                        Alert(title: Text("Invalid Zip Code!"), message: Text("Please enter a valid Zip Code"), dismissButton: .default(Text("OK")))
                        
                    }
                    else {
                        Alert(title: Text("Invalid Address"), message: Text("Please enter a valid address!"), dismissButton: .default(Text("OK")))
                    }
                }
                .navigationTitle("Register")
                
            }// end of list, button is not inside of list
        
            
      // }
    // }
        
    
    // end of view braket
    // defining a function to store the data
    private func storeData(){
        let newCustomerInfo = CustomerInfo()
        newCustomerInfo.userName = username
        newCustomerInfo.email = email
        newCustomerInfo.street = address // address in db
        newCustomerInfo.province = selectedProvince.rawValue
        newCustomerInfo.zipCode = zipcode
        newCustomerInfo.phoneNumber = phoneNum // phone num in db
        newCustomerInfo.password = password // psw in db
        newCustomerInfo.country = country // country in db
        newCustomerInfo.full_name = fullName // full name in db
        newCustomerInfo.city = city // city in db
        newCustomerInfo.profileImageData = imageData
        custmerModel.addCustomer(newCustomerInfo: newCustomerInfo)
        clearText()
       
    }
    private func clearText(){
        username = ""
        fullName = ""
        address = "" // street is the address
        email  = ""
        phoneNum = ""
        password = ""
        city = ""
        zipcode = ""
        country = ""
        // for picker
        selectedProvince = .on
    }
    private func isValidPhone(){
        validphone = ((phoneNum.count == 10) && (phoneNum.range(of: "^[0-9]+$", options: .regularExpression)) != nil)
    }
    private func isValidName(){
        validname = fullName.range(of: "^[a-zA-Z]+$", options: .regularExpression) != nil
    }
    private func isVaildEmail(){
        validemail = email.range(of: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$", options: .regularExpression) != nil
    }
    private func isValidZipcode(){
        if (zipcode.count == 6) {
            validZip = true
        }
        else {
            validZip = false
        }
    }
    private func canGoNext(){
        isValidPhone()
        isValidName()
        isVaildEmail()
        isValidZipcode()
        if (validname && validemail && validphone && validZip && username != "" && fullName != "" && address != "" && city != "" && country != ""){
            gotoNext = true
            storeData()
            showAlert = false
        }
        else {
            gotoNext = false
            showAlert = true
        }
        
    }
}



//
//  MAPD714_002_TeamProject_Team2App.swift
//  MAPD714-002_TeamProject_Team2
//
//  Created by Windy on 2024-10-29.
//
// so this is the main project file
import SwiftUI

@main
struct MAPD714_002_TeamProject_Team2App: App {
    // set up an observer object
    @StateObject private var phoneInfo = PhoneInfo()
    @StateObject private var customerInfo = CustomerInfo()
    // for persistance
    let persistenceController = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                ContentView()
            }
            
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
            // inject the environment object
                .environmentObject(phoneInfo)
                .environmentObject(customerInfo)
            
            
        }
    }
}

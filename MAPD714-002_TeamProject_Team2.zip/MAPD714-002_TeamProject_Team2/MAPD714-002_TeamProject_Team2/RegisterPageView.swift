// this is not needed
//  ConfirmationPageView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-11.
//
import SwiftUI
struct RegisterPageView: View {
    // declear the variable
    @State var username: String = ""
    @State var password: String = ""
    @State var email: String = ""
    var body: some View {
        VStack(alignment: .leading, spacing: 10){
            Text("Please Enter Your Email:").fontWeight(.bold).font(.title2).offset(y:-120)
            TextField("", text: $email).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3).offset(y:-110)
        }
        .padding()
        
        VStack(alignment: .leading, spacing: 10){
            Text("Please Enter Your User Name:").fontWeight(.bold).font(.title2).offset(y:-100)
            TextField("", text: $username).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3).offset(y:-90)
        }
        .padding()
        
        VStack(alignment: .leading, spacing: 10){
            Text("Please Enter Your password:").fontWeight(.bold).font(.title2).offset(y:-80)
            SecureField("", text: $password).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3).offset(y:-70)
        }
        .padding()
        
        /*NavigationLink(destination: PhonePageView(username: $username)) {
            Text("Start shopping").fontWeight(.bold)
        }.frame(width: 200, height: 50).background(.gray).cornerRadius(25).foregroundColor(.black).offset(y:-50)*/
        
    }
       
}

#Preview {
    RegisterPageView()
}

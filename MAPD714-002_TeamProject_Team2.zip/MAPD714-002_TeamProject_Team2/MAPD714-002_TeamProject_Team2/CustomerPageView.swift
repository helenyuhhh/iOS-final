//
//  ConfirmationPageView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-11.
//
// this is not used 

import SwiftUI
enum Provinces: String, CaseIterable, Identifiable {
        case on = "Ontario", qc = "Quebec", ab  = "Alberta", bc =  "Brithsh Columbia", choose = ""
        var id: Self { self }
    }
struct CustomerPageView: View {
    // import the customer info
    @EnvironmentObject var customerInfo: CustomerInfo
    @State var selectedProvince: Provinces = .on

    var body: some View {
        
        VStack{
            Text("Customer Information").font(.title).fontWeight(.bold)
                .padding(.top,10)
            VStack{
                // user name
                List{
                    HStack(){
                        Text("Name:").fontWeight(.bold).font(.title3)
                        TextField("", text: $customerInfo.userName).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3)
                    }
                    // user email
                    HStack(){
                        Text("Email:").fontWeight(.bold).font(.title3)
                        TextField("", text: $customerInfo.email).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3)
                    }
                    // user street
                    HStack(){
                        Text("Street:").fontWeight(.bold).font(.title3)
                        TextField("", text: $customerInfo.street).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3)
                    }
                    HStack(){
                        Text("Province:").fontWeight(.bold).font(.title3)
                        Picker("", selection: $selectedProvince){
                            Text("Ontario").tag(Provinces.on)
                            Text("Quebec").tag(Provinces.qc)
                            Text("British Columbia").tag(Provinces.bc)
                            Text("Alberta").tag(Provinces.ab)
                        }
                     
                    }
                    // zip code
                    HStack(){
                        Text("Zip Code:").fontWeight(.bold).font(.title3)
                        TextField("", text: $customerInfo.zipCode).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3)
                    }
                    // phone number
                    HStack(){
                        Text("Phone Number:").fontWeight(.bold).font(.title3)
                        TextField("", text: $customerInfo.phoneNumber).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3)
                    }
                }
               
            }
            NavigationLink(destination: PaymentPageView()) {
                Text("Payment").fontWeight(.bold)
            }.frame(width: 200, height: 50).background(Color(red: 0.28, green: 0.85, blue: 0.98, opacity: 0.35)).cornerRadius(25).foregroundColor(.black).offset(y:-150).simultaneousGesture(TapGesture().onEnded {
                assignValue()
            })
        }
    }
    private func assignValue(){
        customerInfo.province = selectedProvince.rawValue
    }
}

// preview function for class with environment object
struct CustomerPageView_Previews: PreviewProvider {
    // declare the variable to pass the
    // value?
    static var previews: some View {
        CustomerPageView().environmentObject(CustomerInfo())
    }
}

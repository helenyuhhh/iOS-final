//
//  AfterLoginCustomerInfoView.swift
//  MAPD714-002_TeamProject_Team2
//
//  Created by Windy on 2024-11-19.
//

import SwiftUI

struct AfterLoginCustomerInfoView: View {
    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    AfterLoginCustomerInfoView()
}

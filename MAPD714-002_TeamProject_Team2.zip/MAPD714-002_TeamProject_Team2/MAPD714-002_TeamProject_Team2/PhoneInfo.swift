//
//  ConfirmationPageView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-11.
//

// define an observable class to hold the data
import SwiftUI

class PhoneInfo: ObservableObject {
    @Published var phoneModel: String = ""
    @Published var phoneColor: String = ""
    @Published var phoneStorage: String = ""
    @Published var phonePrice: Int = 0
    @Published var phoneType: String = ""
}



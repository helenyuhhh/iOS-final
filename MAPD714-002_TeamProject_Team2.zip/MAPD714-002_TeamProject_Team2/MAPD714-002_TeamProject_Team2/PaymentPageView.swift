//
//  ConfirmationPageView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-11.
//
import SwiftUI

struct PaymentPageView: View {
    @State var cardName: String = ""
    @State var cardNumber: String = ""
    //@State var expiryDate: String = "" //month year
    @State var cvv: String = "" // 3 digit
    @State var street: String = ""
    @State var city: String = ""
    @State var zip: String = ""
    // picker wheel for expire date
    @State var selectedMonth = 1 // set default value to selectedMonth
    @State var selectedYear = "2024" // set default value to selectedYear
    @State var isValidCVV: Bool = true
    @State var isValidCardNum: Bool = true
    @State var gotoNext: Bool = false
    @State var showAlert: Bool = false
    // define array for month and year
    let months: [Int] = Array(1...12)
    let years: [String] = ["25", "26", "27", "28", "29", "30", "31"]
    var body: some View {
       
            VStack{
                /*Text("Customer Information").font(.title).fontWeight(.bold)
                 .padding(.top,10)*/
                List{
                    VStack(alignment: .leading){
                        Text("Cardholder Name:").fontWeight(.bold).font(.title3)
                        TextField("", text: $cardName).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3)
                    }
                    // user email
                    VStack(alignment: .leading){
                        Text("Card Number:").fontWeight(.bold).font(.title3)
                        TextField("", text: $cardNumber).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3)
                    }
                    HStack{
                        // hold exp
                        VStack(){
                            Text("Expire Date:").fontWeight(.bold).font(.title3)
                            HStack{
                                Picker("Month", selection: $selectedMonth){
                                    // for each method of swift
                                    ForEach(months, id: \.self){ month in
                                        Text("\(month)").tag(month)
                                    }
                                }.pickerStyle(.wheel).frame(width: 70, height:70).clipped()
                                Picker("Year", selection: $selectedYear){
                                    // for each method of swift
                                    ForEach(years, id: \.self){ year in
                                        Text("\(year)").tag(year)
                                    }
                                }.pickerStyle(.wheel).frame(width: 100, height:70).clipped()
                            }
                        }
                        // hold pin
                        VStack(alignment: .leading){
                            Text("CVV:").fontWeight(.bold).font(.title3)
                            TextField("", text: $cvv).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3)
                        }//.onAppear(){checkCvv()}
                    }
                    
                    VStack(alignment: .leading){
                        Text("Address:").fontWeight(.bold).font(.title3)
                        TextField("", text: $street).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3)
                    }
                    VStack(alignment: .leading){
                        Text("Postal Code:").fontWeight(.bold).font(.title3)
                        TextField("", text: $zip).frame(height:50).foregroundColor(.primary).background(.cyan).opacity(0.3)
                        
                    }
                    
                }
                Button(action: {canGoNext()}) {
                                Text("Check Out")
                        .font(.title3).fontWeight(.bold).frame(width: 200, height: 50)
                        .background(Color(red: 0.24, green: 0.75, blue: 0.99, opacity: 0.39))
                                    .foregroundColor(.black).cornerRadius(25)
                            }
                
                .padding()
                
                NavigationLink(destination: DeliveryView(), isActive: $gotoNext){}.alert(isPresented: $showAlert){
                    if (!isValidCardNum){
                        Alert(title: Text("Invalid Card Number"), message: Text("Please enter a valid card number"), dismissButton: .default(Text("OK")))
                    }
                    else if (!isValidCVV){
                        Alert(title: Text("Invalid CVV"), message: Text("Please enter a valid cvv"), dismissButton: .default(Text("OK")))
                    }
                    else {
                        Alert(title: Text("Invalid address"), message: Text("Please enter a address"), dismissButton: .default(Text("OK")))
                        
                    }
                }
                
            }
            .navigationTitle("Payment")
            
            
            // remark: there's something wrong with the gotoNext,
            // when the card number is valid, goToNext is still false
            // how can I solve it?
            
            
        }
    
    
    private func checkCardNum(){
        // invalid
        isValidCardNum = ((cardNumber.count == 16) && (cardNumber.range(of: "^[0-9]+$", options: .regularExpression)) != nil)
    }
    
    private func checkCvv(){
        // invalid
        isValidCVV = ((cvv.count == 3) && (cvv.range(of: "^[0-9]+$", options: .regularExpression)) != nil)
    }
    private func canGoNext(){
        checkCardNum()
        checkCvv()
        if (isValidCVV && isValidCardNum && street != "" && zip != ""){
            gotoNext = true
            showAlert = false
            // store the order to db
        }
        else {
            gotoNext = false
            showAlert = true
        }
    }
    
   
}

#Preview {
    PaymentPageView()
}

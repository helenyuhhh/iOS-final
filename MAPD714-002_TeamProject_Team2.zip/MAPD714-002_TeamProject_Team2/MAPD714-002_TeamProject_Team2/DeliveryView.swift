//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-12-09.
import SwiftUI

enum PickupAddress: String, CaseIterable, Identifiable {
        case progress = "941 Progress Ave, Scarborough, M1G 3TA", shtonbee = "75 Ashtonbee Rd, M1L 4N4", morningSide  = "755 Morningside Ave, M1C 5J9", sac =  "951 Carlaw Ave., Toronto, M4K 3M2", delivery = ""
        var id: Self { self }
    }
enum DeliveryAddress: String, CaseIterable, Identifiable {
    case database = "Home Address", differentAddress = "different"
    var id: Self { self }
}
struct DeliveryView: View {
    @State var sendTo: String = ""
    @State var tempAddress: String = ""
    @State var selectedCampus: PickupAddress = .delivery

    @State var selectedAddress: DeliveryAddress = .database
    @State var showEditAddress: Bool = false
    @State private var address: String = "" // street is the address
    @State private var city: String = ""
    //@State private var province: String = ""
    @State private var zipcode: String = ""
    @State private var country: String = ""
    @State var selectedProvince: Provinces = .choose
    @State private var navigate: Bool = true
   
    
    var body: some View {
        VStack{
            VStack{
                Text("Pickup ?").fontWeight(.bold).font(.largeTitle).frame(alignment:.leading).padding(.leading, -180).padding(.top,-50)
                List{
                    Picker("Pick Up Location", selection: $selectedCampus){
                        Text("Delivery").tag(PickupAddress.delivery)
                        Text("Progress Ave").tag(PickupAddress.progress)
                        Text("Ashtonbee Campous").tag(PickupAddress.shtonbee)
                        Text("Morning Side").tag(PickupAddress.morningSide)
                        Text("SAC Campus").tag(PickupAddress.sac)
                        // phoneModel = "\(selectedModel)"
                    }
                    Text("Your Pickup Location: \n\(selectedCampus.rawValue)")
                   }.frame(height:200).padding(.top, -20)
            }.offset(y:50)
            VStack{
              Text("OR Delivery ?").fontWeight(.bold).font(.largeTitle).frame(alignment:.leading).padding(.leading,-160 )
              List{
                // this is for the same
                  Picker("Delivery To: ", selection: $selectedAddress){
                      Text("Home Address").tag(DeliveryAddress.database)
                      Text("Different Address").tag(DeliveryAddress.differentAddress)
                  }
                  
                  if selectedAddress == .differentAddress {
                          HStack(){
                              Text("Street:").fontWeight(.bold).font(.headline)
                              TextField("", text:$address).frame(height:35).foregroundColor(.primary).background(.cyan).opacity(0.3)
                          }
                          // city
                          HStack(){
                              Text("City:").fontWeight(.bold).font(.headline)
                              TextField("", text:$city).frame(height:35).foregroundColor(.primary).background(Color.mint).opacity(0.3)
                          }
                          // province
                          HStack(){
                              Text("Province:").fontWeight(.bold).font(.headline)
                              Picker("", selection: $selectedProvince){
                                  Text("Select").tag(Provinces.choose)
                                  Text("Ontario").tag(Provinces.on)
                                  Text("Quebec").tag(Provinces.qc)
                                  Text("British Columbia").tag(Provinces.bc)
                                  Text("Alberta").tag(Provinces.ab)
                              }
                          }
                          // country
                          HStack(){
                              Text("Country:").fontWeight(.bold).font(.headline)
                              TextField("", text:$country).frame(height:35).foregroundColor(.primary).background(Color.mint).opacity(0.3)
                          }
                          // zip code
                          HStack(){
                              Text("Zip Code:").fontWeight(.bold).font(.title3)
                              TextField("", text:$zipcode).frame(height:35).foregroundColor(.primary).background(.cyan).opacity(0.3)
                          }
                  }// end of if
              } // end of list
            }.offset(y: 60) //end of 2nd vs
            // button and a navigation
        }// end of the big stack
        NavigationLink(destination: ConfirmationPageView(passedAddress: sendTo)) {
            Text("Continue").font(.title3)
                .fontWeight(.bold)
                .frame(width: 350, height: 50)
                .background(Color.blue.opacity(0.3))
                .foregroundColor(.black)
            .cornerRadius(25)
        }.simultaneousGesture(TapGesture().onEnded {
            assignValue()
        })
        .onAppear(){
            assignValue()
        }
  } // end of body view
    private func assignValue(){
        // pick up,
        if (selectedCampus != .delivery && selectedAddress == .database) {
            sendTo = selectedCampus.rawValue
        }
        //delivery to home
        if (selectedAddress == .database && selectedCampus == .delivery){
            sendTo = "old address"
        }
        if (selectedCampus == .delivery && selectedAddress == .differentAddress) {
            sendTo = "\(address) \(city) \(selectedProvince.rawValue) \(country) \(zipcode)"
        }
        
    }
    private func canGoNext(){
        assignValue()
        if (sendTo != ""){
            navigate = true
        }
        else {
            navigate = false
        }
    }
        
}// end of class

#Preview {
    DeliveryView()
}


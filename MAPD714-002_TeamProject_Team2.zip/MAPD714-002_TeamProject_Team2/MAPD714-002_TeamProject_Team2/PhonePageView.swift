//
//  ConfirmationPageView.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-11.
//

import SwiftUI

struct PhonePageView: View {
    //@Binding var username: String
    //@State var phoneModel: String
    @StateObject var custmerModel = PhoneDBViewModel(context: PersistenceController.shared.container.viewContext)
    @State var username: String
    var body: some View {
        HStack{
            Text("Welcome \(username),").fontWeight(.bold).font(.largeTitle).frame(alignment:.leading).padding(.leading, -20)
            NavigationLink(destination: CustomerInfoViewTwo()){
                Image(systemName: "person.circle.fill").resizable().frame(width: 45, height: 45)
            }.padding(.leading, 55)
        }
        
        TabView{
            // iphone page
            List{
                
                NavigationLink(destination: IPhonePageView()){
                    HStack{
                        //navigation or list?
                        
                        Image("iphone").resizable().aspectRatio(contentMode: .fit).foregroundStyle(.tint).frame(width:100,height:100)
                            .padding()
                        VStack{
                            Text("IPhone").fontWeight(.bold).font(.title2)
                            Text("Starting from $900")
                        }
                    }.padding()
                    
                }.frame(width:400,height:150)
                
                // samsung page
                NavigationLink(destination: SamsungPageView()){
                    HStack{
                        //navigation or list?
                        
                        Image("samsung").resizable().aspectRatio(contentMode: .fit).foregroundStyle(.tint).frame(width:100,height:100)
                            .padding()
                        VStack{
                            Text("Samsung").fontWeight(.bold).font(.title2)
                            Text("Starting from $900")
                        }
                    }.padding()
                    
                }.frame(width:400,height:150)
                //.tabItem {
               
                        //.tabItem {
                        // Label("Settings", systemImage: "gear")
                        // }
                
                // google pixel
                NavigationLink(destination: PixelPageView()){
                    HStack{
                        //navigation or list?
                        
                        Image("pixel").resizable().aspectRatio(contentMode: .fit).foregroundStyle(.tint).frame(width:100,height:100)
                            .padding()
                        VStack{
                            Text("Google Pixel").fontWeight(.bold).font(.title2)
                            Text("Starting from $900")
                        }
                    }
                    .padding()
                    
                }.frame(width:400,height:150)
                
            }// end of list
            .tabItem {
             Label("Shop", systemImage: "cart")
            }
            //
            NavigationView {
                ConfirmationPageView(passedAddress:"old address")
                       }
                .tabItem {
                Label("Orders", systemImage: "list.bullet.rectangle")
            }
        }
        
    }
}

/*struct PhonePageView_Previews: PreviewProvider {
    @State static var username = "" // declare the variable to pass the
    // value?
    static var previews: some View {
        PhonePageView(username: $username)
    }
}*/

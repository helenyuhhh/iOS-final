//
//  PersistenceController.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-19.
//
// this is the step 1,step 2 is to create the core data
import Foundation
import CoreData
// confused about this part
class PersistenceController {
    
    static let shared = PersistenceController()
    // define a container
    let container: NSPersistentContainer
    
    init() {
        // load up core data
        container = NSPersistentContainer(name: "PhoneDB")
        // load the data from the container
        container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
            else {
                print("Successfully loaded core data")
            }
        }
    }
}

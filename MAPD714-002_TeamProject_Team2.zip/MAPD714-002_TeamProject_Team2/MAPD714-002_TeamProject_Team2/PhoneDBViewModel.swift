//
//  PhoneDBViewModel.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-19.
// class for core db view model class, add fetch function here?

import Foundation
import CoreData

class PhoneDBViewModel: ObservableObject {
    // array of saved customer info object
    @Published var customers: [Customer] = []
    private let viewContext: NSManagedObjectContext

   
    init(context: NSManagedObjectContext) {
        viewContext = context
        // user define method to fetch data from Product
        fetchCustomerInfo()
    }
    // fetch the customer
    func fetchCustomerInfo(){
        let request = NSFetchRequest<Customer>(entityName: "Customer")
        do {
            // the fetch result will be saved into saved customer
            customers = try viewContext.fetch(request)
        } catch {
            print("Error in fetching customer: \(error)")
        }
    }
    
    // add a customer
    func addCustomer(newCustomerInfo: CustomerInfo){
        let newCustomer = Customer(context: viewContext)
        newCustomer.full_name = newCustomerInfo.full_name
        newCustomer.address = newCustomerInfo.street
        newCustomer.phone_num = newCustomerInfo.phoneNumber
        newCustomer.email = newCustomerInfo.email
        newCustomer.password = newCustomerInfo.password
        newCustomer.province = newCustomerInfo.province
        newCustomer.city = newCustomerInfo.city
        newCustomer.country = newCustomerInfo.country
        newCustomer.zipcode = newCustomerInfo.zipCode
        newCustomer.username = newCustomerInfo.userName
        if let profileData = newCustomerInfo.profileImageData {
            newCustomer.profile = profileData as NSObject
            }
        saveContext()
    }
    
    // edit the info
    func editCustomer(_ customer: Customer, with newInfo: CustomerInfo) {
        customer.password = newInfo.password
        customer.phone_num = newInfo.phoneNumber
        customer.address = newInfo.street
        customer.province = newInfo.province
        customer.city = newInfo.city
        customer.country = newInfo.country
        customer.zipcode = newInfo.zipCode
        if let profileData = newInfo.profileImageData {
            customer.profile = profileData as NSObject
            }
        
        saveContext()
    }
    
    
    private func saveContext() {
        do {
            // .save() is the way to add
            try viewContext.save()
            fetchCustomerInfo()
        } catch {
            print("Error in saving context: \(error)")
        }
    }
    
}

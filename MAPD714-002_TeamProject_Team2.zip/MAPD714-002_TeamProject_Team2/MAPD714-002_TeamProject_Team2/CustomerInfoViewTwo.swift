//
//  CustomerInfoViewTwo.swift
//  MAPD714-002_TeamProject_Team2
//  Qianhui Yu 301462989
//  Nirmala Thapa 301365723
//  Created by Windy on 2024-11-25.
//

import SwiftUI

struct CustomerInfoViewTwo: View {
    @StateObject var custmerModel = PhoneDBViewModel(context: PersistenceController.shared.container.viewContext)
    //@StateObject var custmerModel = PhoneDBViewModel(context: PersistenceController.shared.container.viewContext)
    @State private var showingEditView = false
    @State private var editableCustomer: Customer?

    var body: some View {
        NavigationView {
            VStack {
                if custmerModel.customers.isEmpty {
                    Text("No customer found").fontWeight(.bold).font(.title2)
                } else {
                    let customer = custmerModel.customers.last
                    if let customer = customer {
                        if let profileData = customer.profile as? Data, let uiImage = UIImage(data: profileData){
                            Image(uiImage:uiImage)
                                .resizable().frame(width:100, height:100).clipShape(Circle()).overlay(Circle().stroke(Color.white, lineWidth:3)).shadow(radius: 3).scaledToFit()
                        }else{
                            Circle().fill(Color.gray.opacity(0.5)).frame(width:100, height:100).overlay((Text("Profile")).foregroundColor(.white))
                        }
                        List {
                            Text("Your name: \(customer.full_name ?? "N/A")")
                                .fontWeight(.bold).font(.headline)
                            Text("Your username: \(customer.username ?? "N/A")")
                                .fontWeight(.bold).font(.headline)
                            Text("Email: \(customer.email ?? "N/A")")
                                .fontWeight(.bold).font(.headline)
                            Text("Phone Number: \(customer.phone_num ?? "N/A")")
                                .fontWeight(.bold).font(.headline)
                            Text("Street: \(customer.address ?? "N/A")")
                                .fontWeight(.bold).font(.headline)
                            Text("City: \(customer.city ?? "N/A")")
                                .fontWeight(.bold).font(.headline)
                            Text("Province: \(customer.province ?? "N/A")")
                                .fontWeight(.bold).font(.headline)
                            Text("Zipcode: \(customer.zipcode ?? "N/A")")
                                .fontWeight(.bold).font(.headline)
                            
                            // NavigationLink for starting shopping
                            NavigationLink(destination: PhonePageView(username: customer.username ?? "Guest")) {
                                    Text("Start shopping").fontWeight(.bold).padding(.leading, 100)}
                            .frame(width: 300, height: 50).background(Color.gray).cornerRadius(25).foregroundColor(.white).padding(.leading, 20)
                            }
                        }
                    }
                }
            }
            .onAppear {
                fetchData()
            }
            .navigationBarTitle("Customer Profile")
            .navigationBarItems(trailing: Button(action: {
                self.editableCustomer = nil
                self.showingEditView = true
            }) {
                Image(systemName: "pencil.and.outline")
            })
            .sheet(isPresented: $showingEditView) {
                CustomerInfoEditView(customerModel: custmerModel, editableCustomer: $editableCustomer)
            }
            
        }
    

    func fetchData() {
        custmerModel.fetchCustomerInfo()
    }
}
